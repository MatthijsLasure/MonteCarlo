#!/bin/bash

export OMP_NUM_THREADS=8
export KMP_AFFINITY=scatter

# Check if directory gauss exists, make if not
if [ ! -d "gauss" ]; then
	echo "Directory gauss does not exist. Creating..."
	mkdir gauss
else
	echo "Clearing Gauss..."
	touch gauss/hey
	rm gauss/*
fi

if [ ! -d "IO" ]; then
	echo "Directory IO does not exist. Creating..."
	mkdir IO
else
	echo "Clearing IO..."
	touch IO/hey
	#rm IO/*

fi

for j in {1..50000};
do
	cp IO/box.$(( j - 1 )).out IO/box.$j.in
	cp IO/solute.$(( j - 1 )).out IO/solute.$j.in

	./MonteCarloOpenMP config1.ini 0 500 $j
done
